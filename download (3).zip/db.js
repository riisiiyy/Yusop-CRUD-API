 const mysql = require('mysql2/promise');

 const connection = mysql.createPool({
   host: 'localhost',
     user: 'yusop_warisa',
       password: ' ',
         database: 'movie_db'
         });